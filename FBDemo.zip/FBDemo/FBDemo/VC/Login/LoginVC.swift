//
//  LoginVC.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//
//Login https://medium.com/firebase-developers/ios-firebase-authentication-sdk-email-and-password-login-6a3bb27e0536

import UIKit

class LoginVC: BaseVC {
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!

    private var loginVM = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if Application.isInDevlopment {
            email.text = "test@gmail.com"
            password.text = "12345678"
        }
    }
    
    private func loginAuth() {
        ShowLoaderOnView()
        loginVM.email = email.text ?? ""
        loginVM.password = password.text ?? ""
        loginVM.loginAuth { (success, msg) in
            HideLoaderOnView()
            if success {
                self.gotoDeshboard()
            } else {
                self.alert(message: msg)
            }
        }
    }

    private func gotoDeshboard() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DeshboardVC") as? DeshboardVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }

    @IBAction func onBtnLogin(_ sender: Any) {
        loginAuth()
    }

    @IBAction func onBtnSignup(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
