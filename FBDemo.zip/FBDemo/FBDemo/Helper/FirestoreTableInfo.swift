//
//  FirestoreTableInfo.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation

class FirestoreTableInfo {
    //Tables
    static let users =   "Users"
}
