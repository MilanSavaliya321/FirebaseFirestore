//
//  UpdateProfileViewModel.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation

class UpdateProfileViewModel: BaseVM {

    var userInfo: UsersModel!

    func updateUserProfileDocument(completionHandeler: @escaping ((_ success: Bool, _ message: String)->())) {

        let washingtonRef = db.collection(FirestoreTableInfo.users).document(userInfo.documentId)

        washingtonRef.updateData([
            "name": userInfo.name,
            "email": userInfo.email,
            "city": userInfo.city,
            "phone": userInfo.phone,
            "password": userInfo.password
        ]) { err in
            if let err = err {
                completionHandeler(false, err.localizedDescription)
                DLog("Error updating document: \(err)")
            } else {
                completionHandeler(true, "Document successfully updated")
                DLog("Document successfully updated")
            }
        }
    }
}
