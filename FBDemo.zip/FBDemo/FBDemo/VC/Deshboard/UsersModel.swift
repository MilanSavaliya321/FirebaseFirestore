//
//  UsersModel.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

class UsersModel {
    
    var documentId = ""
    var name = ""
    var email = ""
    var password = ""
    var phone = ""
    var city = ""

    init() { }
    
    init(json: [String: Any], documentId: String = "") {
        self.documentId = documentId
        name = json["name"] as? String ?? ""
        email = json["email"] as? String ?? ""
        password = json["password"] as? String ?? ""
        phone = json["phone"] as? String ?? ""
        city = json["city"] as? String ?? ""
    }
}
