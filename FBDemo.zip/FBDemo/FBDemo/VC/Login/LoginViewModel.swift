//
//  LoginVM.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation
import Firebase

class LoginViewModel: BaseVM {

    var email: String = ""
    var password: String = ""

    func loginAuth(completionHandeler: @escaping ((_ success: Bool, _ message: String)->())) {
        Auth.auth().signIn(withEmail: email, password: password) { (authResult, error) in
            HideLoaderOnView()
            if let error = error as NSError? {
                switch AuthErrorCode(rawValue: error.code) {
                case .operationNotAllowed:
                    DLog("operationNotAllowed")
                    completionHandeler(false,"operationNotAllowed")
                    break
                case .userDisabled:
                    DLog("userDisabled")
                    completionHandeler(false,"userDisabled")
                    break

                case .wrongPassword:
                    DLog("wrongPassword")
                    completionHandeler(false,"wrongPassword")
                    break

                case .invalidEmail:
                    DLog("invalidEmail")
                    completionHandeler(false,"invalidEmail")
                    break

                default:
                    completionHandeler(false,"invalidEmail")
                    DLog("Error: \(error.localizedDescription)")
                }
            } else {
                DLog("User Login successfully")
                completionHandeler(true,"User Login successfully")
                //            let userInfo = Auth.auth().currentUser
                //            let email = userInfo?.email
            }
        }
    }
    
}
