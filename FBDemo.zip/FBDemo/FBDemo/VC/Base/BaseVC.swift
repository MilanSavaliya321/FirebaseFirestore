//
//  BaseVC.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import UIKit

class BaseVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
