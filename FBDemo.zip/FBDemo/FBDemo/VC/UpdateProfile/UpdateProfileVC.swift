//
//  UpdateProfileVC.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import UIKit

class UpdateProfileVC: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var city: UITextField!

    var userInfo: UsersModel!
    let updateProfileViewModel = UpdateProfileViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        email.text = userInfo.email
        password.text = userInfo.password
        name.text = userInfo.name
        city.text = userInfo.city
        phone.text = userInfo.phone
    }

    private func updateUserProfileDocument() {
        let info = UsersModel()
        info.documentId = userInfo.documentId
        info.email = email.text ?? ""
        info.password = password.text ?? ""
        info.name = name.text ?? ""
        info.city = city.text ?? ""
        info.phone = phone.text ?? ""

        updateProfileViewModel.userInfo = info
        ShowLoaderOnView()
        updateProfileViewModel.updateUserProfileDocument { (success, msg) in
            HideLoaderOnView()
            if success {
                self.alert(message: msg)
                NotificationCenter.default.post(Notification.init(name: Notification.Name("UpdateData")))
            } else {
                self.alert(message: msg)
            }
        }
    }

    @IBAction func onBtnUpdateProfile(_ sender: Any) {
        updateUserProfileDocument()
    }
}
