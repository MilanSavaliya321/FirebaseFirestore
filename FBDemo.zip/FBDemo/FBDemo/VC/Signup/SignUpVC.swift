//
//  SignUpVC.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//
import UIKit

class SignUpVC: BaseVC {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var city: UITextField!

    private let signupVM = SignupViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    private func signupAuth() {
        signupVM.email = email.text ?? ""
        signupVM.password = password.text ?? ""
        signupVM.name = name.text ?? ""
        signupVM.city = city.text ?? ""
        signupVM.phone = phone.text ?? ""

        ShowLoaderOnView()
        signupVM.signupAuth { (success, msg) in
            HideLoaderOnView()
            if success {
                self.alert(message: msg)
            } else {
                self.alert(message: msg)
            }
        }
    }

    @IBAction func onBtnSignUp(_ sender: UIButton) {
        signupAuth()
    }

}
