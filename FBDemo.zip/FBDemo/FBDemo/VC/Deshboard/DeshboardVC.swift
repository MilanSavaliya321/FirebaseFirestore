//
//  DeshboardVC.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import UIKit
import Firebase

//firestore https://github.com/firebase/snippets-ios/blob/6e0f6fb63dbd97f61c62522e09ffa16ce580fb9f/firestore/swift/firestore-smoketest/ViewController.swift#L156-L168

class DeshboardVC: BaseVC {
    @IBOutlet weak var tblUsers: UITableView!

    let deshboardViewModel = DeshboardViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        NotificationCenter.default.addObserver(self, selector: #selector(getUsersCollection), name: Notification.Name("UpdateData"), object: nil)
    }

    private func setupUI() {
        self.navigationItem.setHidesBackButton(true, animated: true)
        let btnLogout = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logout))
        self.navigationItem.rightBarButtonItem  = btnLogout
        setupTableView()
        getUsersCollection()
    }

    @objc private func getUsersCollection() {
        ShowLoaderOnView()
        deshboardViewModel.getUsersCollection { (success, msg) in
            HideLoaderOnView()
            DispatchQueue.main.async {
                if success {
                    self.tblUsers.reloadData()
                } else {
                    self.alert(message: msg)
                }
            }
        }
    }

    private func setupTableView() {
        tblUsers.delegate = self
        tblUsers.dataSource = self
        tblUsers.register(UINib(nibName: "UsersCell", bundle: nil), forCellReuseIdentifier: "UsersCell")
    }

    @objc func logout() {
        do {
            try Auth.auth().signOut()
            DLog("Sign out Sucessfully")
            self.navigationController?.popToRootViewController(animated: true)
        } catch {
            DLog("Sign out error")
        }
    }
}

// MARK: - UITableViewDelegate,UITableViewDataSource
extension DeshboardVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        deshboardViewModel.arrUsers.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UsersCell") as? UsersCell else {return UITableViewCell()}
        cell.email.text = deshboardViewModel.arrUsers[indexPath.row].email
        cell.name.text = deshboardViewModel.arrUsers[indexPath.row].name
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "UpdateProfileVC") as? UpdateProfileVC
        vc?.userInfo = deshboardViewModel.arrUsers[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
