//
//  UsersCell.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import UIKit

class UsersCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }
    
}
