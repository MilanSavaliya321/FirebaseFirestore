//
//  SignupVM.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation
import Firebase

class SignupViewModel: BaseVM {

    var name: String = ""
    var email: String = ""
    var password: String = ""
    var city: String = ""
    var phone: String = ""

    func signupAuth(completionHandeler: @escaping ((_ success: Bool, _ message: String)->()) ) {

        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error as NSError? {
                switch AuthErrorCode(rawValue: error.code) {
                case .operationNotAllowed:
                    completionHandeler(false, "operationNotAllowed")
                    DLog("operationNotAllowed")
                    break
                case .emailAlreadyInUse:
                    completionHandeler(false, "emailAlreadyInUse")
                    DLog("emailAlreadyInUse")
                    break
                case .invalidEmail:
                    completionHandeler(false, "invalidEmail")
                    DLog("invalidEmail")
                    break
                case .weakPassword:
                    completionHandeler(false, "weakPassword")
                    DLog("weakPassword")
                    break
                default:
                    DLog("Error: \(error.localizedDescription)")
                    completionHandeler(false, error.localizedDescription)
                }
            } else {
                DLog("User signs up successfully")
                self.storeLoginData(completionHandeler: completionHandeler)
                //            let newUserInfo = Auth.auth().currentUser
                //            let email = newUserInfo?.email
            }
        }
    }

    private func storeLoginData(completionHandeler: @escaping ((_ success: Bool, _ message: String)->())) {
        var ref: DocumentReference? = nil
        ref = db.collection(FirestoreTableInfo.users).addDocument(
            data: [
                "name": name,
                "email": email,
                "city": city,
                "phone": phone,
                "password": password
            ]) { error in
            if let error = error {
                completionHandeler(false, error.localizedDescription)
                DLog("Error adding document: \(error)")
            } else {
                completionHandeler(true, "User signs up successfully")
                DLog("Document added with ID: \(ref!.documentID)")
            }
        }
    }

}
