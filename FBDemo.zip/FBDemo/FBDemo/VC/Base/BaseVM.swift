//
//  BaseVM.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation
import Firebase

class BaseVM: NSObject {
    let db = Firestore.firestore()
}
