//
//  DeshboardVM.swift
//  FBDemo
//
//  Created by mac on 10/12/21.
//

import Foundation

class DeshboardViewModel: BaseVM {

    var arrUsers = [UsersModel]()

    func getUsersCollection(completionHandeler: @escaping ((_ success: Bool, _ message: String)->())) {
        db.collection(FirestoreTableInfo.users).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
                completionHandeler(false, err.localizedDescription)
            } else {
                
                guard let usersJson = querySnapshot?.documents else{
                    return
                }
                self.arrUsers.removeAll()
                for user in usersJson {
                    let user = UsersModel(json: user.data(), documentId: user.documentID)
                    self.arrUsers.append(user)
                }
                completionHandeler(true, "get users successfully")
            }
        }
    }

}
